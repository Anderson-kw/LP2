﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pSalario
{
    public partial class form1 : Form
    {
        public form1()
        {
            InitializeComponent();
        }

        private void mskbxnomeFunc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter inválido");
                SendKeys.Send("{BACKSPACE}");
            }
        }
        private void btnDesc_Click(object sender, EventArgs e)
        {
            
            double descINSS;
            double salLiquido;
            salLiquido = salBruto;
            

            if (salBruto <= 800.47)
            {
                txtaliqINSS.Text = "7,65%";
                descINSS = 0.0765 * salBruto;
                txtdescINSS.Text = descINSS.ToString();
                salLiquido = salLiquido - descINSS;
            }
            else
                if (salBruto <= 1050)
            {
                txtaliqINSS.Text = "8,65%";
                descINSS = 0.0865 * salBruto;
                txtdescINSS.Text = descINSS.ToString();
                salLiquido = salLiquido - descINSS;
            }
            else
                if (salBruto <= 1400.77)
            {
                txtaliqINSS.Text = "9.00%";
                descINSS = 0.09 * salBruto;
                txtdescINSS.Text = descINSS.ToString();
                salLiquido = salLiquido - descINSS;
            }
            else
                if (salBruto <= 2801.56)
            {
                txtaliqINSS.Text = "11.00%";
                descINSS = 0.11 * salBruto;
                txtdescINSS.Text = descINSS.ToString();
                salLiquido = salLiquido - descINSS;
            }
            else
                if (salBruto > 2801.56)
            {
                txtaliqINSS.Text = "Teto";
                descINSS = 308.17;
                txtdescINSS.Text = descINSS.ToString();
                salLiquido = salLiquido - descINSS;
            }

            double descIRPF;

            if (salBruto < 1257.12)
            {
                txtaliqIRPF.Text = "isento";
                descIRPF = 0;
                txtDescIRPF.Text = "0,00";
                salLiquido = salLiquido - descIRPF;
            }
            else
                if (salBruto <= 2512.08)
            {
                txtaliqIRPF.Text = "15.00%";
                descIRPF = 0.15 * salBruto;
                txtDescIRPF.Text = descIRPF.ToString("N2");
                salLiquido = salLiquido - descIRPF;
            }
            else
                if (salBruto > 2512.08)
            {
                txtaliqIRPF.Text = "27.5%";
                descIRPF = 0.275 * salBruto;
                txtDescIRPF.Text = descIRPF.ToString("N2");
                salLiquido = salLiquido - descIRPF;
            }
            double salFamilia;
            if (salBruto < 435.52)
            {
                salFamilia = 22.33 * numFilhos;
                txtsalFamilia.Text = salFamilia.ToString();
                salLiquido = salLiquido + salFamilia;
            }    
            else
                if (salBruto <= 654.61)
            {
                salFamilia = 15.74 * numFilhos;
                txtsalFamilia.Text = salFamilia.ToString();
                salLiquido = salLiquido + salFamilia;
            }
            else
                if (salBruto> 654.61)
            {
                salFamilia = 0;
                txtsalFamilia.Text = salFamilia.ToString();
                salLiquido = salLiquido + salFamilia;
            }

            txtsalLiquido.Text = salLiquido.ToString("N2");

        }

        double salBruto;
        private void mskbxsalBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxsalBruto.Text, out salBruto))
            {
                MessageBox.Show("Número inválido");
                mskbxsalBruto.Focus();
            }
        }
        double numFilhos;

        private void NupFilhos_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(NupFilhos.Text, out numFilhos))
                {
                MessageBox.Show("Sim");
            }
        }
    }
}
