﻿namespace pSalario
{
    partial class form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnomeFunc = new System.Windows.Forms.Label();
            this.lblsalBruto = new System.Windows.Forms.Label();
            this.lblnumFilho = new System.Windows.Forms.Label();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblaliqIRPF = new System.Windows.Forms.Label();
            this.lblsalFamilia = new System.Windows.Forms.Label();
            this.lblsalLiquido = new System.Windows.Forms.Label();
            this.lbldescINSS = new System.Windows.Forms.Label();
            this.lbldescIRPF = new System.Windows.Forms.Label();
            this.NupFilhos = new System.Windows.Forms.NumericUpDown();
            this.btnDesc = new System.Windows.Forms.Button();
            this.txtaliqINSS = new System.Windows.Forms.TextBox();
            this.txtaliqIRPF = new System.Windows.Forms.TextBox();
            this.txtsalFamilia = new System.Windows.Forms.TextBox();
            this.txtsalLiquido = new System.Windows.Forms.TextBox();
            this.txtdescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.mskbxnomeFunc = new System.Windows.Forms.MaskedTextBox();
            this.mskbxsalBruto = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.NupFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblnomeFunc
            // 
            this.lblnomeFunc.AutoSize = true;
            this.lblnomeFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnomeFunc.Location = new System.Drawing.Point(32, 32);
            this.lblnomeFunc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblnomeFunc.Name = "lblnomeFunc";
            this.lblnomeFunc.Size = new System.Drawing.Size(235, 31);
            this.lblnomeFunc.TabIndex = 0;
            this.lblnomeFunc.Text = "Nome Funcionário";
            // 
            // lblsalBruto
            // 
            this.lblsalBruto.AutoSize = true;
            this.lblsalBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalBruto.Location = new System.Drawing.Point(32, 85);
            this.lblsalBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsalBruto.Name = "lblsalBruto";
            this.lblsalBruto.Size = new System.Drawing.Size(170, 31);
            this.lblsalBruto.TabIndex = 1;
            this.lblsalBruto.Text = "Salário Bruto";
            // 
            // lblnumFilho
            // 
            this.lblnumFilho.AutoSize = true;
            this.lblnumFilho.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnumFilho.Location = new System.Drawing.Point(32, 138);
            this.lblnumFilho.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblnumFilho.Name = "lblnumFilho";
            this.lblnumFilho.Size = new System.Drawing.Size(218, 31);
            this.lblnumFilho.TabIndex = 2;
            this.lblnumFilho.Text = "Número de filhos";
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliqINSS.Location = new System.Drawing.Point(32, 315);
            this.lblAliqINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(183, 31);
            this.lblAliqINSS.TabIndex = 3;
            this.lblAliqINSS.Text = "Aliquota INSS";
            // 
            // lblaliqIRPF
            // 
            this.lblaliqIRPF.AutoSize = true;
            this.lblaliqIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaliqIRPF.Location = new System.Drawing.Point(32, 369);
            this.lblaliqIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblaliqIRPF.Name = "lblaliqIRPF";
            this.lblaliqIRPF.Size = new System.Drawing.Size(182, 31);
            this.lblaliqIRPF.TabIndex = 4;
            this.lblaliqIRPF.Text = "Aliquota IRPF";
            // 
            // lblsalFamilia
            // 
            this.lblsalFamilia.AutoSize = true;
            this.lblsalFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalFamilia.Location = new System.Drawing.Point(32, 420);
            this.lblsalFamilia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsalFamilia.Name = "lblsalFamilia";
            this.lblsalFamilia.Size = new System.Drawing.Size(192, 31);
            this.lblsalFamilia.TabIndex = 5;
            this.lblsalFamilia.Text = "Salário Família";
            // 
            // lblsalLiquido
            // 
            this.lblsalLiquido.AutoSize = true;
            this.lblsalLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalLiquido.Location = new System.Drawing.Point(31, 475);
            this.lblsalLiquido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsalLiquido.Name = "lblsalLiquido";
            this.lblsalLiquido.Size = new System.Drawing.Size(192, 31);
            this.lblsalLiquido.TabIndex = 6;
            this.lblsalLiquido.Text = "Salário Liquido";
            // 
            // lbldescINSS
            // 
            this.lbldescINSS.AutoSize = true;
            this.lbldescINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldescINSS.Location = new System.Drawing.Point(516, 315);
            this.lbldescINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldescINSS.Name = "lbldescINSS";
            this.lbldescINSS.Size = new System.Drawing.Size(201, 31);
            this.lbldescINSS.TabIndex = 7;
            this.lbldescINSS.Text = "Desconto INSS";
            // 
            // lbldescIRPF
            // 
            this.lbldescIRPF.AutoSize = true;
            this.lbldescIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldescIRPF.Location = new System.Drawing.Point(516, 369);
            this.lbldescIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldescIRPF.Name = "lbldescIRPF";
            this.lbldescIRPF.Size = new System.Drawing.Size(200, 31);
            this.lbldescIRPF.TabIndex = 8;
            this.lbldescIRPF.Text = "Desconto IRPF";
            // 
            // NupFilhos
            // 
            this.NupFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NupFilhos.Location = new System.Drawing.Point(339, 138);
            this.NupFilhos.Margin = new System.Windows.Forms.Padding(4);
            this.NupFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.NupFilhos.Name = "NupFilhos";
            this.NupFilhos.Size = new System.Drawing.Size(125, 34);
            this.NupFilhos.TabIndex = 3;
            this.NupFilhos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NupFilhos.Validated += new System.EventHandler(this.NupFilhos_Validated);
            // 
            // btnDesc
            // 
            this.btnDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesc.Location = new System.Drawing.Point(304, 215);
            this.btnDesc.Margin = new System.Windows.Forms.Padding(4);
            this.btnDesc.Name = "btnDesc";
            this.btnDesc.Size = new System.Drawing.Size(268, 57);
            this.btnDesc.TabIndex = 10;
            this.btnDesc.Text = "Verificar Desconto";
            this.btnDesc.UseVisualStyleBackColor = true;
            this.btnDesc.Click += new System.EventHandler(this.btnDesc_Click);
            // 
            // txtaliqINSS
            // 
            this.txtaliqINSS.Enabled = false;
            this.txtaliqINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaliqINSS.Location = new System.Drawing.Point(245, 315);
            this.txtaliqINSS.Margin = new System.Windows.Forms.Padding(4);
            this.txtaliqINSS.Name = "txtaliqINSS";
            this.txtaliqINSS.Size = new System.Drawing.Size(217, 34);
            this.txtaliqINSS.TabIndex = 13;
            // 
            // txtaliqIRPF
            // 
            this.txtaliqIRPF.Enabled = false;
            this.txtaliqIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaliqIRPF.Location = new System.Drawing.Point(247, 369);
            this.txtaliqIRPF.Margin = new System.Windows.Forms.Padding(4);
            this.txtaliqIRPF.Name = "txtaliqIRPF";
            this.txtaliqIRPF.Size = new System.Drawing.Size(217, 34);
            this.txtaliqIRPF.TabIndex = 14;
            // 
            // txtsalFamilia
            // 
            this.txtsalFamilia.Enabled = false;
            this.txtsalFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalFamilia.Location = new System.Drawing.Point(245, 420);
            this.txtsalFamilia.Margin = new System.Windows.Forms.Padding(4);
            this.txtsalFamilia.Name = "txtsalFamilia";
            this.txtsalFamilia.Size = new System.Drawing.Size(217, 34);
            this.txtsalFamilia.TabIndex = 15;
            // 
            // txtsalLiquido
            // 
            this.txtsalLiquido.Enabled = false;
            this.txtsalLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalLiquido.Location = new System.Drawing.Point(245, 475);
            this.txtsalLiquido.Margin = new System.Windows.Forms.Padding(4);
            this.txtsalLiquido.Name = "txtsalLiquido";
            this.txtsalLiquido.Size = new System.Drawing.Size(217, 34);
            this.txtsalLiquido.TabIndex = 16;
            // 
            // txtdescINSS
            // 
            this.txtdescINSS.Enabled = false;
            this.txtdescINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdescINSS.Location = new System.Drawing.Point(732, 315);
            this.txtdescINSS.Margin = new System.Windows.Forms.Padding(4);
            this.txtdescINSS.Name = "txtdescINSS";
            this.txtdescINSS.Size = new System.Drawing.Size(217, 34);
            this.txtdescINSS.TabIndex = 17;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescIRPF.Location = new System.Drawing.Point(732, 369);
            this.txtDescIRPF.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(217, 34);
            this.txtDescIRPF.TabIndex = 18;
            // 
            // mskbxnomeFunc
            // 
            this.mskbxnomeFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxnomeFunc.Location = new System.Drawing.Point(339, 32);
            this.mskbxnomeFunc.Margin = new System.Windows.Forms.Padding(4);
            this.mskbxnomeFunc.Name = "mskbxnomeFunc";
            this.mskbxnomeFunc.Size = new System.Drawing.Size(509, 37);
            this.mskbxnomeFunc.TabIndex = 1;
            this.mskbxnomeFunc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mskbxnomeFunc_KeyPress);
            // 
            // mskbxsalBruto
            // 
            this.mskbxsalBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxsalBruto.Location = new System.Drawing.Point(339, 85);
            this.mskbxsalBruto.Margin = new System.Windows.Forms.Padding(4);
            this.mskbxsalBruto.Mask = "##000.00";
            this.mskbxsalBruto.Name = "mskbxsalBruto";
            this.mskbxsalBruto.Size = new System.Drawing.Size(160, 37);
            this.mskbxsalBruto.TabIndex = 2;
            this.mskbxsalBruto.Validated += new System.EventHandler(this.mskbxsalBruto_Validated);
            // 
            // form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(987, 554);
            this.Controls.Add(this.mskbxsalBruto);
            this.Controls.Add(this.mskbxnomeFunc);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtdescINSS);
            this.Controls.Add(this.txtsalLiquido);
            this.Controls.Add(this.txtsalFamilia);
            this.Controls.Add(this.txtaliqIRPF);
            this.Controls.Add(this.txtaliqINSS);
            this.Controls.Add(this.btnDesc);
            this.Controls.Add(this.NupFilhos);
            this.Controls.Add(this.lbldescIRPF);
            this.Controls.Add(this.lbldescINSS);
            this.Controls.Add(this.lblsalLiquido);
            this.Controls.Add(this.lblsalFamilia);
            this.Controls.Add(this.lblaliqIRPF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.lblnumFilho);
            this.Controls.Add(this.lblsalBruto);
            this.Controls.Add(this.lblnomeFunc);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.NupFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnomeFunc;
        private System.Windows.Forms.Label lblsalBruto;
        private System.Windows.Forms.Label lblnumFilho;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblaliqIRPF;
        private System.Windows.Forms.Label lblsalFamilia;
        private System.Windows.Forms.Label lblsalLiquido;
        private System.Windows.Forms.Label lbldescINSS;
        private System.Windows.Forms.Label lbldescIRPF;
        private System.Windows.Forms.NumericUpDown NupFilhos;
        private System.Windows.Forms.Button btnDesc;
        private System.Windows.Forms.TextBox txtaliqINSS;
        private System.Windows.Forms.TextBox txtaliqIRPF;
        private System.Windows.Forms.TextBox txtsalFamilia;
        private System.Windows.Forms.TextBox txtsalLiquido;
        private System.Windows.Forms.TextBox txtdescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.MaskedTextBox mskbxnomeFunc;
        private System.Windows.Forms.MaskedTextBox mskbxsalBruto;
    }
}

