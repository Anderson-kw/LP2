﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
        double Lado1, Lado2, Lado3;

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!(Math.Abs(Lado2 - Lado3) < Lado1 && Lado1 < (Lado2 + Lado3)))
            {
                MessageBox.Show("Triângulo inválido");
            }
            else
                if (!(Math.Abs(Lado1 - Lado2) < Lado2 && Lado2 < (Lado1 + Lado3)))
            {
                MessageBox.Show("Triângulo inválido");
            }
            else
                    if (!(Math.Abs(Lado1 - Lado2) < Lado3 && Lado3 < (Lado1 + Lado2))) 
            {
                MessageBox.Show("Triângulo inválido");
            }
            else
                        if (Lado1 == Lado2 && Lado2 == Lado3)
                txtTriangulo.Text = "Triângulo equilátero";
            else
                            if (Lado1 == Lado2 && Lado2 != Lado3)
                txtTriangulo.Text = "Triângulo isóceles";
            else
                                if (Lado1 != Lado2 && Lado2 != Lado3)
                txtTriangulo.Text = "Triângulo escaleno";
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            Lado1 = 0;
            Lado2 = 0;
            Lado3 = 0;
            txtLado1.Text = "";
            txtLado2.Text = "";
            txtLado3.Text = "";
            txtTriangulo.Text = "";
        }

        private void txtLado3_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado3.Text, out Lado3))
            {
                MessageBox.Show("Número inválido");
                txtLado3.Focus();
            }
            else
                if (Lado3 <= 0)
                {
                    MessageBox.Show("Lado deve ser maior que zero");
                    txtLado3.Focus();
                }
        }

        private void txtLado2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado2.Text, out Lado2))
            {
                MessageBox.Show("Número inválido");
                txtLado2.Focus();
            }
            else
                if (Lado2 <= 0)
            {
                MessageBox.Show("Lado deve ser maior que zero");
                txtLado2.Focus();
            }
        }

        private void txtLado1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado1.Text, out Lado1))
            {
                MessageBox.Show("Número inválido");
                txtLado1.Focus();
            }
            else
                if (Lado1 <= 0) {
                MessageBox.Show("Lado deve ser maior que zero");
                txtLado1.Focus();
            }
        }
    }
}
