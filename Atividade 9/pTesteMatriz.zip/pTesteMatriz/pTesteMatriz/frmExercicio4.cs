﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace pTesteMatriz
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] strings = new string[4];
            string auxiliar = "";

            for (int i = 0; i < strings.Length; i++)
            {
                strings[i] = Interaction.InputBox($"Insira {i+1}º nome");
                for (int j = 0; j < strings[i].Length; j++)
                {
                    if (!char.IsWhiteSpace(strings[i][j]))
                    {
                        auxiliar += strings[i][j];
                    }
                }
                listBox1.Items.Add("O nome: " + strings[i] + " tem "+ auxiliar.Length + " caracteres.");
                
            }
            
        }
    }
}
