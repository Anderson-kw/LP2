﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace pTesteMatriz
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[,] strings = new string[40, 10];
            string[] gabarito = new string[] {"A","B","C","D","E","A","B","C","D","E"};

            for (int i = 0; i < strings.GetLength(0); i++)
            {
                listBox1.Items.Add($"Aluno {i+1}");

                for (int j = 0; j < strings.GetLength(1); j++)
                {
                    strings[i, j] = Interaction.InputBox($"Insira a {j+1}ª resposta do {i+1}º aluno");
                    if (!(strings[i, j] == "A" || strings[i, j] == "B" || strings[i, j] == "C" || strings[i, j] == "D" || strings[i, j] == "E"))
                    {
                        MessageBox.Show("Resposta inválida");
                        j--;
                    }
                    else if (strings[i, j] == gabarito[j])
                    {
                        listBox1.Items.Add($"Questão {j+1}: Resposta correta\n");
                    }
                    else
                    {
                        listBox1.Items.Add($"Questão {j+1}: Resposta incorreta\n");
                    }
                }
            }



        }
    }
}
