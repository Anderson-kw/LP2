﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        double vlrNum1, vlrNum2, vlrResultado;
        private void txtNumero1_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(txtNumero1.Text, out vlrNum1))
            {
                MessageBox.Show("Numero 1 inválido");
                txtNumero1.Focus();
            }                   
         }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out vlrNum2))
            {
                MessageBox.Show("Numero 2 inválido");
                txtNumero2.Focus();
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {

            vlrResultado = vlrNum1 + vlrNum2;
            txtResultado.Text = vlrResultado.ToString();
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            vlrResultado = vlrNum1 - vlrNum2;
            txtResultado.Text = vlrResultado.ToString();
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            vlrResultado = vlrNum1 * vlrNum2;
            txtResultado.Text = vlrResultado.ToString("N2");
        }

        private void brtDivisao_Click(object sender, EventArgs e)
        {

            if (vlrNum2 == 0)
            {
                MessageBox.Show("Não divisivel por zero");
            }
            else
            {
                vlrResultado = vlrNum1 / vlrNum2;
                txtResultado.Text = vlrResultado.ToString("N2");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = "";
            txtNumero2.Text = "";
            txtResultado.Text = "";
            vlrNum1 = 0;
            vlrNum2 = 0;
            vlrResultado = 0;

        }
    }
}

