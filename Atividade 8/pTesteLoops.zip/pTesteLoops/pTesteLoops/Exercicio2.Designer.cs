﻿namespace pTesteLoops
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblN = new Label();
            txtN = new TextBox();
            btnH = new Button();
            SuspendLayout();
            // 
            // lblN
            // 
            lblN.AutoSize = true;
            lblN.Font = new Font("Segoe UI", 16.2F);
            lblN.Location = new Point(169, 107);
            lblN.Name = "lblN";
            lblN.Size = new Size(38, 38);
            lblN.TabIndex = 0;
            lblN.Text = "N";
            // 
            // txtN
            // 
            txtN.Font = new Font("Segoe UI", 16.2F);
            txtN.Location = new Point(262, 107);
            txtN.Name = "txtN";
            txtN.Size = new Size(179, 43);
            txtN.TabIndex = 2;
            // 
            // btnH
            // 
            btnH.Font = new Font("Segoe UI", 16.2F);
            btnH.Location = new Point(262, 298);
            btnH.Name = "btnH";
            btnH.Size = new Size(200, 80);
            btnH.TabIndex = 3;
            btnH.Text = "H";
            btnH.UseVisualStyleBackColor = true;
            btnH.Click += btnH_Click;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnH);
            Controls.Add(txtN);
            Controls.Add(lblN);
            Name = "frmExercicio2";
            Text = "Exercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblN;
        private TextBox txtN;
        private Button btnH;
    }
}