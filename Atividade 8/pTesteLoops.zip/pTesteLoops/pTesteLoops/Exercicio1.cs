﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTesteLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int Branco = 0;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                    Branco++;
            }
            MessageBox.Show("Quantidade de espaço em branco: " + Branco);
        }

        private void btnNumerosR_Click(object sender, EventArgs e)
        {
            int R = 0,cont = 0;

            do
            {
                if (char.ToUpper(rchtxtFrase.Text[cont]) == 'R')
                    R++;
                cont++;
            }
            while (cont < rchtxtFrase.Text.Length);

            MessageBox.Show("Quantidade de letras R: " + R);
        }

        private void brnPardeLetras_Click(object sender, EventArgs e)
        {
            int Par = 0, cont = 1 ;


            while (cont < rchtxtFrase.Text.Length)   
            {
                if (char.ToUpper(rchtxtFrase.Text[cont]) == char.ToUpper(rchtxtFrase.Text[cont - 1]))
                    Par ++ ;
                cont++;
            }
            MessageBox.Show("Números de pares de letras: " + Par);
        }
    }
}
