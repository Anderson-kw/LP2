﻿namespace pTesteLoops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btnEspacoBranco = new Button();
            btnNumerosR = new Button();
            brnPardeLetras = new Button();
            lblFrase = new Label();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Font = new Font("Segoe UI", 12F);
            rchtxtFrase.Location = new Point(276, 58);
            rchtxtFrase.MaxLength = 100;
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(308, 120);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // btnEspacoBranco
            // 
            btnEspacoBranco.Font = new Font("Segoe UI", 13.8F);
            btnEspacoBranco.Location = new Point(62, 298);
            btnEspacoBranco.Name = "btnEspacoBranco";
            btnEspacoBranco.Size = new Size(200, 80);
            btnEspacoBranco.TabIndex = 1;
            btnEspacoBranco.Text = "Espaços em branco";
            btnEspacoBranco.UseVisualStyleBackColor = true;
            btnEspacoBranco.Click += btnEspacoBranco_Click;
            // 
            // btnNumerosR
            // 
            btnNumerosR.Font = new Font("Segoe UI", 13.8F);
            btnNumerosR.Location = new Point(299, 298);
            btnNumerosR.Name = "btnNumerosR";
            btnNumerosR.Size = new Size(200, 80);
            btnNumerosR.TabIndex = 2;
            btnNumerosR.Text = "Números de R";
            btnNumerosR.UseVisualStyleBackColor = true;
            btnNumerosR.Click += btnNumerosR_Click;
            // 
            // brnPardeLetras
            // 
            brnPardeLetras.Font = new Font("Segoe UI", 13.8F);
            brnPardeLetras.Location = new Point(540, 298);
            brnPardeLetras.Name = "brnPardeLetras";
            brnPardeLetras.Size = new Size(200, 80);
            brnPardeLetras.TabIndex = 3;
            brnPardeLetras.Text = "Par de letras";
            brnPardeLetras.UseVisualStyleBackColor = true;
            brnPardeLetras.Click += brnPardeLetras_Click;
            // 
            // lblFrase
            // 
            lblFrase.AutoSize = true;
            lblFrase.Font = new Font("Segoe UI", 13.8F);
            lblFrase.Location = new Point(128, 94);
            lblFrase.Name = "lblFrase";
            lblFrase.Size = new Size(67, 31);
            lblFrase.TabIndex = 4;
            lblFrase.Text = "Frase";
            // 
            // frmExercicio1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblFrase);
            Controls.Add(brnPardeLetras);
            Controls.Add(btnNumerosR);
            Controls.Add(btnEspacoBranco);
            Controls.Add(rchtxtFrase);
            Name = "frmExercicio1";
            Text = "Exercicio1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btnEspacoBranco;
        private Button btnNumerosR;
        private Button brnPardeLetras;
        private Label lblFrase;
    }
}