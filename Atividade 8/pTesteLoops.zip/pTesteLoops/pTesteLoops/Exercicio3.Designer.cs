﻿namespace pTesteLoops
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtboxPalavra = new TextBox();
            btnPalindromo = new Button();
            lblPalavra = new Label();
            SuspendLayout();
            // 
            // txtboxPalavra
            // 
            txtboxPalavra.Font = new Font("Segoe UI", 13.8F);
            txtboxPalavra.Location = new Point(300, 141);
            txtboxPalavra.MaxLength = 50;
            txtboxPalavra.Name = "txtboxPalavra";
            txtboxPalavra.Size = new Size(187, 38);
            txtboxPalavra.TabIndex = 0;
            // 
            // btnPalindromo
            // 
            btnPalindromo.Font = new Font("Segoe UI", 13.8F);
            btnPalindromo.Location = new Point(300, 298);
            btnPalindromo.Name = "btnPalindromo";
            btnPalindromo.Size = new Size(200, 80);
            btnPalindromo.TabIndex = 1;
            btnPalindromo.Text = "Palindromo ?";
            btnPalindromo.UseVisualStyleBackColor = true;
            btnPalindromo.Click += button1_Click;
            // 
            // lblPalavra
            // 
            lblPalavra.AutoSize = true;
            lblPalavra.Font = new Font("Segoe UI", 13.8F);
            lblPalavra.Location = new Point(85, 141);
            lblPalavra.Name = "lblPalavra";
            lblPalavra.Size = new Size(178, 31);
            lblPalavra.TabIndex = 2;
            lblPalavra.Text = "Frase ou Palavra";
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblPalavra);
            Controls.Add(btnPalindromo);
            Controls.Add(txtboxPalavra);
            Name = "frmExercicio3";
            Text = "Exercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtboxPalavra;
        private Button btnPalindromo;
        private Label lblPalavra;
    }
}