﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTesteLoops
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnSalBruto_Click(object sender, EventArgs e)
        {
            double SalBruto, B = 0, C = 0, D = 0;

            if (Producao >= 100)
                B = 1.0;

            if (Producao >= 110)
                C = 1.0;
            if (Producao >= 150)
                D = 1.0;

            SalBruto = A + A * (0.05 * B + 0.01 * C + 0.1 * D) + Gratificacao;

            if (SalBruto > 7000 && Producao >= 150 && Gratificacao > 0)
            {
                MessageBox.Show("Salário bruto = " + SalBruto);
            }
            else
                if(SalBruto > 7000)
                MessageBox.Show("Salário bruto = 7000.0");
            else
                MessageBox.Show("Salário bruto = " + SalBruto);
        }

        double A, Producao, Gratificacao;
        private void txtSalario_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtSalario.Text, out A))
            {
                MessageBox.Show("Salario inválido");
                txtSalario.Focus();
            }
        }

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtProducao.Text, out Producao))
            {
                MessageBox.Show("Produção inválido");
                txtProducao.Focus();
            }
        }

        private void txtGratificacao_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtGratificacao.Text, out Gratificacao))
            {
                MessageBox.Show("Gratificação inválido");
                txtGratificacao.Focus();
            }
        }
    }
}
