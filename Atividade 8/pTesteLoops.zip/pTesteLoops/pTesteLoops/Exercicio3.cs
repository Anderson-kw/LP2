﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTesteLoops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string palavra = new(txtboxPalavra.Text.Replace(" ","").Reverse().ToArray());

            if (palavra.ToUpper() == txtboxPalavra.Text.Replace(" ","").ToUpper())
            {
                MessageBox.Show("A palavra " + txtboxPalavra.Text + " é palíndromo");
            }
            else
            {
                MessageBox.Show("A palavra " + txtboxPalavra.Text + " não é palíndromo");
            }


        }
    }
}
