﻿namespace pTesteLoops
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtNome = new TextBox();
            txtMatricula = new TextBox();
            txtProducao = new TextBox();
            txtSalario = new TextBox();
            txtGratificacao = new TextBox();
            btnSalBruto = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F);
            label1.Location = new Point(127, 43);
            label1.Name = "label1";
            label1.Size = new Size(76, 31);
            label1.TabIndex = 0;
            label1.Text = "Nome";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F);
            label2.Location = new Point(127, 92);
            label2.Name = "label2";
            label2.Size = new Size(111, 31);
            label2.TabIndex = 1;
            label2.Text = "Matrícula";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F);
            label3.Location = new Point(127, 139);
            label3.Name = "label3";
            label3.Size = new Size(111, 31);
            label3.TabIndex = 2;
            label3.Text = "Produção";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 13.8F);
            label4.Location = new Point(127, 192);
            label4.Name = "label4";
            label4.Size = new Size(83, 31);
            label4.TabIndex = 3;
            label4.Text = "Salário";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 13.8F);
            label5.Location = new Point(127, 245);
            label5.Name = "label5";
            label5.Size = new Size(136, 31);
            label5.TabIndex = 4;
            label5.Text = "Gratificação";
            // 
            // txtNome
            // 
            txtNome.Font = new Font("Segoe UI", 13.8F);
            txtNome.Location = new Point(300, 40);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(264, 38);
            txtNome.TabIndex = 5;
            // 
            // txtMatricula
            // 
            txtMatricula.Font = new Font("Segoe UI", 13.8F);
            txtMatricula.Location = new Point(300, 89);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(264, 38);
            txtMatricula.TabIndex = 6;
            // 
            // txtProducao
            // 
            txtProducao.Font = new Font("Segoe UI", 13.8F);
            txtProducao.Location = new Point(300, 136);
            txtProducao.Name = "txtProducao";
            txtProducao.Size = new Size(264, 38);
            txtProducao.TabIndex = 7;
            txtProducao.Validated += txtProducao_Validated;
            // 
            // txtSalario
            // 
            txtSalario.Font = new Font("Segoe UI", 13.8F);
            txtSalario.Location = new Point(300, 185);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(264, 38);
            txtSalario.TabIndex = 8;
            txtSalario.Validated += txtSalario_Validated;
            // 
            // txtGratificacao
            // 
            txtGratificacao.Font = new Font("Segoe UI", 13.8F);
            txtGratificacao.Location = new Point(300, 238);
            txtGratificacao.Name = "txtGratificacao";
            txtGratificacao.Size = new Size(264, 38);
            txtGratificacao.TabIndex = 9;
            txtGratificacao.Validated += txtGratificacao_Validated;
            // 
            // btnSalBruto
            // 
            btnSalBruto.Font = new Font("Segoe UI", 13.8F);
            btnSalBruto.Location = new Point(300, 298);
            btnSalBruto.Name = "btnSalBruto";
            btnSalBruto.Size = new Size(200, 80);
            btnSalBruto.TabIndex = 10;
            btnSalBruto.Text = "Salário Bruto";
            btnSalBruto.UseVisualStyleBackColor = true;
            btnSalBruto.Click += btnSalBruto_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSalBruto);
            Controls.Add(txtGratificacao);
            Controls.Add(txtSalario);
            Controls.Add(txtProducao);
            Controls.Add(txtMatricula);
            Controls.Add(txtNome);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmExercicio4";
            Text = "Exercicio4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtNome;
        private TextBox txtMatricula;
        private TextBox txtProducao;
        private TextBox txtSalario;
        private TextBox txtGratificacao;
        private Button btnSalBruto;
    }
}