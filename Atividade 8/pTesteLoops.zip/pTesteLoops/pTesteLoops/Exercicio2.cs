﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTesteLoops
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        double N;
        private void btnH_Click(object sender, EventArgs e)
        {
            double H = 0;

            if (!double.TryParse(txtN.Text, out N))
            {
                MessageBox.Show("Número inválido");
                txtN.Focus();
            }
            else
            {
                for (double i = 1; i <= N; i++)
                {
                    H = H + (1 / i);
                }
                MessageBox.Show("H = " + H);
            }
        }
    }
}

