namespace pTesteLoops
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exerc�cio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio1>().Count() > 0)
            {
                //Application.OpenForms["frmExercicio1"].BringToFront();

                Application.OpenForms["frmExercicio1"].Activate();
            }

            else
            {
                frmExercicio1 objForm1 = new frmExercicio1();
                objForm1.MdiParent = this;
                objForm1.WindowState = FormWindowState.Maximized;
                objForm1.Show();
            }

            frmExercicio1 objFrm1 = new frmExercicio1();
            objFrm1.MdiParent = this;
            objFrm1.WindowState = FormWindowState.Maximized;
            objFrm1.Show();
        }

        private void exerc�cio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0)
            {
                //Application.OpenForms["frmExercicio2"].BringToFront();

                Application.OpenForms["frmExercicio2"].Activate();
            }
            else
            {
                frmExercicio2 objForm2 = new frmExercicio2();
                objForm2.MdiParent = this;
                objForm2.WindowState = FormWindowState.Maximized;
                objForm2.Show();
            }

            frmExercicio2 objFrm2 = new frmExercicio2();
            objFrm2.MdiParent = this;
            objFrm2.WindowState = FormWindowState.Maximized;
            objFrm2.Show();
        }

        private void exerc�cio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
            {
                //Application.OpenForms["frmExercicio3"].BringToFront();

                Application.OpenForms["frmExercicio3"].Activate();
            }
            else
            {
                frmExercicio3 objForm3 = new frmExercicio3();
                objForm3.MdiParent = this;
                objForm3.WindowState = FormWindowState.Maximized;
                objForm3.Show();
            }

            frmExercicio3 objFrm3 = new frmExercicio3();
            objFrm3.MdiParent = this;
            objFrm3.WindowState = FormWindowState.Maximized;
            objFrm3.Show();
        }

        private void exerc�cio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                //Application.OpenForms["frmExercicio4"].BringToFront();

                Application.OpenForms["frmExercicio4"].Activate();
            }
            else
            {
                frmExercicio4 objForm4 = new frmExercicio4();
                objForm4.MdiParent = this;
                objForm4.WindowState = FormWindowState.Maximized;
                objForm4.Show();
            }

            frmExercicio4 objFrm4 = new frmExercicio4();
            objFrm4.MdiParent = this;
            objFrm4.WindowState = FormWindowState.Maximized;
            objFrm4.Show();
        }
    }
}
